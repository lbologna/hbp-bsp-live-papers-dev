import neuron
from neuron import h

h.load_file('stdrun.hoc')
h.load_file('fig7.hoc')
#h.init()
#h.finitialize()

#global v_vec

#v_vec=[]

#CVOde = h.cvode
#CVOde.active(1)

#h.celsius=34
#Vrest=-70 #mV

#h.v_init=Vrest

v = h.Vector()
v.record(h.soma[0](0.5)._ref_v)
t = h.Vector()
t.record(h._ref_t)

